// Эффект плавного появления секций
const sections = document.querySelectorAll('section');
sections.forEach(section => {
    section.style.opacity = 0; 
    section.style.transition = 'opacity 1s'; 
});

let opacity = 0;
const fadeIn = setInterval(() => {
    if (opacity < 1) {
        opacity += 0.1;
        sections.forEach(section => section.style.opacity = opacity);
    } else {
        clearInterval(fadeIn);
    }
}, 100);

// Глобальная переменная для аудио
let music;

window.addEventListener("DOMContentLoaded", function() {
    // Создаем объект аудио
    music = new Audio("music/background-music.mp3");
    music.loop = true; // Включаем зацикливание

    // Проверяем состояние музыки
    const isPlaying = localStorage.getItem("musicPlaying");

    if (isPlaying === "true") {
        music.play();
    }

    // Добавляем обработчик для переключения состояния музыки
    document.getElementById("music-toggle").addEventListener("click", toggleMusic);
});

// Функция для переключения состояния музыки
function toggleMusic() {
    if (music.paused) {
        music.play();
        localStorage.setItem("musicPlaying", "true"); // Сохраняем состояние
    } else {
        music.pause();
        localStorage.setItem("musicPlaying", "false"); // Сохраняем состояние
    }
}


